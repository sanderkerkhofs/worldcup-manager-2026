// Apply saved theme immediately (before body renders) to prevent flash
(function () {
  var saved = localStorage.getItem('studydocs-theme');
  var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  var theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
})();

function toggleTheme() {
  var html = document.documentElement;
  var current = html.getAttribute('data-theme');
  var next = current === 'dark' ? 'light' : 'dark';

  // Enable transitions only during the manual switch
  html.classList.add('theme-transitioning');
  html.setAttribute('data-theme', next);
  localStorage.setItem('studydocs-theme', next);
  updateToggleBtn();

  setTimeout(function () {
    html.classList.remove('theme-transitioning');
  }, 300);
}

function updateToggleBtn() {
  var btn = document.getElementById('theme-toggle');
  if (!btn) return;
  var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  btn.textContent = isDark ? '☀️ Light' : '🌙 Dark';
  btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
}

document.addEventListener('DOMContentLoaded', updateToggleBtn);
